#!/usr/bin/env python3
"""Phase 1 ONLY. Standard-library HTTP capture, bounded discovery, contracts, ZIP.
No wallets, takers, signing, build, execute, transaction submission or trading.
Python >=3.10. Run: python live_probe.py [--all]
"""
from __future__ import annotations
import argparse, base64, collections, datetime as dt, hashlib, json, os, re
import socket, sys, time, urllib.error, urllib.parse, urllib.request, uuid, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOL = 'So11111111111111111111111111111111111111112'
USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'
DEX = 'https://api.dexscreener.com'
RUG = 'https://api.rugcheck.xyz'
JUP = 'https://api.jup.ag/swap/v2/order'
XAI = 'https://api.x.ai/v1/responses'
PROVIDERS = ('rugcheck', 'dexscreener', 'jupiter', 'xai')
KEYS = ('XAI_API_KEY', 'JUPITER_API_KEY', 'RUGCHECK_API_KEY')
J_FIELDS = 'inputMint outputMint inAmount outAmount inUsdValue outUsdValue priceImpact priceImpactPct otherAmountThreshold slippageBps routePlan router feeBps requestId quoteId expireAt totalTime'.split()
D_FIELDS = 'priceUsd liquidity.usd pairCreatedAt txns volume fdv marketCap baseToken quoteToken dexId'.split()
R_FIELDS = 'score_normalised risks mintAuthority freezeAuthority lpLockedPct topHolders creator creatorBalance creatorTokens graphInsidersDetected insiderNetworks'.split()
MISSING = object()


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def load_env():
    p = ROOT / '.env'
    allowed = set(KEYS) | {'XAI_MODEL'}
    if p.exists():
        for line in p.read_text(encoding='utf-8-sig').splitlines():
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            k, v = line.split('=', 1)
            if k.strip() in allowed:
                os.environ.setdefault(k.strip(), v.strip().strip('\"\''))


def scrub(raw):
    """Do not write echoed credentials, even in HTTP error bodies."""
    changed = False
    for k in KEYS:
        s = os.environ.get(k, '')
        if s:
            for value in {s, urllib.parse.quote(s, safe=''), base64.b64encode(s.encode()).decode()}:
                if value.encode() in raw:
                    raw = raw.replace(value.encode(), b'[REDACTED_SECRET]')
                    changed = True
    # Remove common credentials if returned by an unexpected intermediary.
    pattern = rb'(?i)("(?:api[_-]?key|authorization|access_token|secret)"\s*:\s*")[^"]*(")'
    previous=raw
    raw = re.sub(pattern, rb'\1[REDACTED_SECRET]\2', raw)
    return raw, changed or raw!=previous


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None  # Never forward API credentials to a redirected host.


class Capture:
    def __init__(self, root, timeout=45, opener=None):
        self.root, self.timeout = root, timeout
        self.opener = opener or urllib.request.build_opener(NoRedirect())
        self.items, self.blocked, self.last = [], {}, {}
        for p in PROVIDERS:
            (root/'tests'/'fixtures'/p).mkdir(parents=True, exist_ok=True)

    def request(self, source, name, endpoint, params=None, body=None, role='probe', labels=None):
        params = params or {}
        host = urllib.parse.urlsplit(endpoint).netloc
        allowed = {'api.rugcheck.xyz', 'api.dexscreener.com', 'api.jup.ag', 'api.x.ai'}
        if host not in allowed or not endpoint.startswith('https://'):
            raise ValueError('Endpoint not in fixed HTTPS allowlist')
        if source == 'jupiter' and (endpoint != JUP or body is not None or set(params)-{'inputMint','outputMint','amount'}):
            raise ValueError('Only Jupiter V2 quote-only requests permitted')
        url = endpoint + ('?' + urllib.parse.urlencode(params) if params else '')
        meta = dict(source=source, endpoint=url, captured_at=now(), http_status=None,
                    provenance='not_captured', api_version={'rugcheck':'v1','dexscreener':'v1','jupiter':'Swap V2','xai':'v1 Responses'}[source],
                    fixture_format_version='1.0', role=role, labels=labels or [], method='POST' if body else 'GET',
                    request_json=body, status='PENDING', server_schema_version='UNCONFIRMED')
        out = {'metadata':meta, 'response':None}
        self.items.append((name, out))
        if host in self.blocked:
            meta.update(status='SKIPPED', reason='HOST_CIRCUIT_OPEN: '+self.blocked[host])
            self.save(source, name, out)
            return out
        # Keyless Jupiter documented at 0.5 RPS; conservative all-host pacing.
        delay = 2.1 - (time.monotonic()-self.last.get(host, 0))
        if delay > 0:
            time.sleep(delay)
        headers = {'Accept':'application/json', 'User-Agent':'Phase1LiveProbe/1.0'}
        key = os.environ.get({'xai':'XAI_API_KEY','jupiter':'JUPITER_API_KEY','rugcheck':'RUGCHECK_API_KEY'}.get(source, ''), '')
        if key:
            headers['Authorization' if source == 'xai' else 'x-api-key'] = ('Bearer ' if source == 'xai' else '')+key
        data = json.dumps(body, separators=(',',':')).encode() if body else None
        if data:
            headers['Content-Type'] = 'application/json'
        start = time.monotonic()
        try:
            try:
                response = self.opener.open(urllib.request.Request(url, data=data, headers=headers), timeout=self.timeout if source != 'xai' else max(180,self.timeout))
            except urllib.error.HTTPError as e:
                response = e
            with response:
                meta['http_status'] = response.code
                meta['response_headers'] = {k.lower():v for k,v in response.headers.items() if k.lower() in {'date','content-type','retry-after','x-request-id','x-api-version'}}
                raw = response.read(12_000_001)
            if len(raw) > 12_000_000:
                meta.update(status='FAIL', reason='BODY_TOO_LARGE; incomplete body not a fixture')
            else:
                safe, redacted = scrub(raw)
                meta.update(provenance='live_capture', status='CAPTURED', captured_at=now(),
                            body_sha256=digest(safe), raw_body_redacted=redacted,
                            raw_body_file=name+'.body', raw_byte_length=len(safe))
                (self.root/'tests'/'fixtures'/source/(name+'.body')).write_bytes(safe)
                try:
                    out['response'] = json.loads(safe)
                    if isinstance(out['response'], dict):
                        meta['server_schema_version'] = out['response'].get('schemaVersion', out['response'].get('version','NOT_AVAILABLE'))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    meta['parse_error'] = 'NON_JSON_BODY'
                if response.code in (401,403,429):
                    self.blocked[host] = 'HTTP_'+str(response.code)
        except (urllib.error.URLError, TimeoutError, socket.timeout, OSError) as e:
            # Exception messages may echo URLs/headers. Store exception class only.
            meta.update(status='NETWORK_ERROR', reason=type(e).__name__)
            self.blocked[host] = type(e).__name__
        finally:
            self.last[host] = time.monotonic()
            meta['elapsed_ms'] = round((time.monotonic()-start)*1000, 2)
        self.save(source, name, out)
        print(f'{source}/{name}: HTTP {meta["http_status"]} {meta["status"]}', flush=True)
        return out

    def save(self, source, name, out):
        dump(self.root/'tests'/'fixtures'/source/(name+'.json'), out)

    def skip(self, source, name, reason):
        out={'metadata':dict(source=source,endpoint=None,captured_at=now(),http_status=None,provenance='not_captured',status='SKIPPED',reason=reason,role='coverage'), 'response':None}
        self.items.append((name,out)); self.save(source,name,out)


def get(obj, path):
    for key in path.split('.'):
        if not isinstance(obj,dict) or key not in obj:
            return MISSING
        obj=obj[key]
    return obj


def typename(v):
    if v is None: return 'null'
    if isinstance(v,bool): return 'boolean'
    if isinstance(v,dict): return 'object'
    if isinstance(v,list): return 'array'
    if isinstance(v,str): return 'string'
    return 'number'


def schema_paths(obj, path='$', found=None):
    found = {} if found is None else found
    found.setdefault(path,set()).add(typename(obj))
    if isinstance(obj,dict):
        for k,v in obj.items(): schema_paths(v,path+'.'+k,found)
    elif isinstance(obj,list):
        for v in obj: schema_paths(v,path+'[]',found)
    return {k:sorted(v) for k,v in found.items()} if path=='$' else found


def find_keys(obj, target, path='$'):
    hits=[]
    if isinstance(obj,dict):
        for k,v in obj.items():
            p=path+'.'+k
            if k==target: hits.append({'path':p,'type':typename(v),'state':'NULL' if v is None else 'PRESENT'})
            hits.extend(find_keys(v,target,p))
    elif isinstance(obj,list):
        for i,v in enumerate(obj): hits.extend(find_keys(v,target,f'{path}[{i}]'))
    return hits


def good(out):
    m=out['metadata']; return m.get('provenance')=='live_capture' and isinstance(m.get('http_status'),int) and 200<=m['http_status']<300 and out['response'] is not None


def positive_quote(out):
    b=out['response']
    return good(out) and isinstance(b,dict) and isinstance(b.get('outAmount'),str) and b['outAmount'].isdigit() and int(b['outAmount'])>0 and b.get('error') is None and not b.get('errorCode')


def pool_observation(pools, mint):
    # priceUsd describes baseToken. Never compare a quote-token price as target price.
    selected=[p for p in pools if isinstance(p,dict) and p.get('chainId')=='solana' and get(p,'baseToken.address')==mint]
    metrics={'deepest_pool':'liquidity.usd','highest_volume_pool':'volume.h24','most_active_pool':'txns.h24'}
    result={'mint':mint,'returned_pool_count':len(pools),'base_token_pool_count':len(selected),'window':'h24','scope':'returned pools only; not exhaustive','winners':{},'missing_metrics':{}}
    for label,field in metrics.items():
        scored=[]; missing=0
        for p in selected:
            v=get(p,field)
            if label=='most_active_pool':
                v=(v['buys']+v['sells']) if isinstance(v,dict) and all(isinstance(v.get(k),(int,float)) and not isinstance(v.get(k),bool) for k in ('buys','sells')) else MISSING
            if isinstance(v,(int,float)) and not isinstance(v,bool): scored.append((v,p.get('pairAddress')))
            else: missing+=1
        result['missing_metrics'][label]=missing
        result['winners'][label]=[{'pairAddress':p,'value':v} for v,p in scored if v==max(x[0] for x in scored)] if scored else []
    sets=[{p['pairAddress'] for p in result['winners'][k]} for k in metrics]
    result['different_winners_observed']=all(sets) and any(sets[i].isdisjoint(sets[j]) for i in range(3) for j in range(i))
    result['all_three_distinct_observed']=all(sets) and all(sets[i].isdisjoint(sets[j]) for i in range(3) for j in range(i))
    return result


def check_fixture(name,out,root):
    m,b=out['metadata'],out['response']; source=m['source']
    r={'fixture':name,'source':source,'status':'PASS','checks':[],'fields':{}}
    def check(field,status,note): r['checks'].append(dict(field=field,status=status,note=note))
    if m.get('provenance')!='live_capture':
        r.update(status='NOT_RUN',reason=m.get('reason',m.get('status'))); return r
    raw=root/'tests'/'fixtures'/source/m.get('raw_body_file','MISSING')
    if not raw.is_file() or digest(raw.read_bytes())!=m.get('body_sha256'):
        check('raw_integrity','FAIL','raw bytes missing or SHA256 mismatch')
    elif b is not None:
        try:
            if json.loads(raw.read_bytes()) != b: check('parsed_integrity','FAIL','Parsed body differs from raw bytes')
        except (ValueError,UnicodeDecodeError): check('parsed_integrity','FAIL','Raw body not JSON')
    if not isinstance(m.get('http_status'),int):
        check('http_status','FAIL','HTTP status unconfirmed')
    elif not 200<=m['http_status']<300:
        # Negative tests are observations, not proof of provider success.
        r['error_body']=b
        r['no_route_explicitly_reported']=source=='jupiter' and bool(re.search(r'NO[_ ]ROUTE|COULD_NOT_FIND.*ROUTE|no route',json.dumps(b),re.I))
        r['error_class']='AUTH' if m['http_status'] in (401,403) else 'RATE_LIMIT' if m['http_status']==429 else 'HTTP_ERROR'
        check('HTTP','FAIL','HTTP '+str(m['http_status'])+'; captured error behavior')
    elif b is None:
        check('json','SCHEMA_CHANGED','Expected JSON response')
    elif m.get('role')=='discovery':
        check('discovery','PASS','Discovery response only; excluded from core success')
    elif source=='rugcheck':
        if not isinstance(b,dict) or 'mint' not in b:
            check('report','SCHEMA_CHANGED','Missing report mint/object')
        else:
            expected=m.get('requested_mint')
            if expected and b['mint']!=expected: check('mint','FAIL','Requested mint mismatch')
            for field in R_FIELDS:
                hits=find_keys(b,field)
                r['fields'][field]=hits or 'NOT_AVAILABLE_IN_THIS_RESPONSE'
            for field,types in {'mint':('string',),'risks':('array',),'score_normalised':('number',),'token':('object',)}.items():
                field_check(b,field,types,True,check)
            for field in ('token.mintAuthority','token.freezeAuthority'):
                field_check(b,field,('string','null'),False,check)
            for field in ('topHolders','markets','insiderNetworks','creatorTokens'):
                field_check(b,field,('array','null'),False,check)
            for field in ('creator','creatorBalance','graphInsidersDetected'):
                field_check(b,field,('string','null') if field=='creator' else ('number','null'),False,check)
            if not find_keys(b,'lpLockedPct'): check('lpLockedPct','OPTIONAL_MISSING','No exact key; no substitute mapping')
    elif source=='dexscreener':
        if not isinstance(b,list): check('root','SCHEMA_CHANGED','Expected token-pairs v1 array')
        elif not b: check('pools','FAIL','No pools returned')
        else:
            for i,p in enumerate(b):
                for field in D_FIELDS:
                    req=field in ('baseToken','quoteToken','dexId')
                    types={'priceUsd':('string','null'),'baseToken':('object',),'quoteToken':('object',),'dexId':('string',),'txns':('object','null'),'volume':('object','null')}.get(field,('number','null'))
                    field_check(p,field,types,req,lambda f,s,n:check(f'[{i}].{f}',s,n))
                for field in ('baseToken.address','quoteToken.address','pairAddress','chainId'):
                    field_check(p,field,('string',),True,lambda f,s,n:check(f'[{i}].{f}',s,n))
            r['pool_observation']=pool_observation(b,m.get('requested_mint',''))
    elif source=='jupiter':
        if not isinstance(b,dict): check('root','SCHEMA_CHANGED','Expected object')
        else:
            for field in J_FIELDS:
                required=field in ('inputMint','outputMint','inAmount','outAmount','routePlan')
                types=('array',) if field=='routePlan' else ('string',) if field in ('inputMint','outputMint','inAmount','outAmount','otherAmountThreshold','router','requestId','quoteId','expireAt') else ('number','string','null')
                field_check(b,field,types,required,check)
            if not positive_quote(out): check('quote','FAIL','No positive usable quote; error/NO_ROUTE requires separate interpretation')
            if b.get('transaction') not in (None,''): check('transaction','FAIL','Unexpected assembled transaction returned')
            for key in ('inputMint','outputMint'):
                if b.get(key)!=m.get('quote_params',{}).get(key): check(key,'FAIL','Requested mint mismatch')
            if b.get('inAmount')!=m.get('quote_params',{}).get('amount'): check('inAmount','FAIL','Requested raw amount mismatch')
            for key in ('inAmount','outAmount'):
                if not isinstance(b.get(key),str) or not b[key].isdigit(): check(key,'SCHEMA_CHANGED','Expected unsigned integer string')
            if not b.get('routePlan'): check('routePlan','FAIL','Empty route')
            r['no_route_explicitly_reported']=bool(re.search(r'NO[_ ]ROUTE|COULD_NOT_FIND.*ROUTE|no route',json.dumps(b),re.I))
    elif source=='xai':
        for field,types in {'id':('string',),'output':('array',),'usage':('object',),'status':('string',)}.items(): field_check(b,field,types,True,check)
        if not isinstance(b,dict) or b.get('status')!='completed': check('completion','FAIL','Response not completed')
        for field in ('x_search_calls','x_posts_fetched','x_users_fetched'):
            field_check(b,'usage.server_side_tool_usage_details.'+field,('number',),False,check)
        count=get(b,'usage.server_side_tool_usage_details.x_search_calls')
        if not isinstance(count,(int,float)) or isinstance(count,bool) or count<1: check('x_search_execution','FAIL','No confirmed successful x_search call')
        text=output_text(b)
        try:
            structured=json.loads(text)
            valid=validate_structured(structured)
            check('structured_output','PASS' if valid else 'SCHEMA_CHANGED','Exact requested schema validation')
        except (ValueError,TypeError): check('structured_output','FAIL','Output text is not JSON')
    severe=[c['status'] for c in r['checks']]
    r['status']='FAIL' if 'FAIL' in severe else 'SCHEMA_CHANGED' if 'SCHEMA_CHANGED' in severe else 'PASS'
    r['optional_missing']=sum(s=='OPTIONAL_MISSING' for s in severe)
    if b is not None: r['observed_schema']=schema_paths(b)
    return r


def field_check(obj,path,types,required,record):
    value=get(obj,path)
    if value is MISSING:
        record(path,'SCHEMA_CHANGED' if required else 'OPTIONAL_MISSING','Missing required field' if required else 'NOT_AVAILABLE_IN_THIS_RESPONSE')
    elif typename(value) not in types:
        record(path,'SCHEMA_CHANGED',f'Expected {types}, observed {typename(value)}')
    else: record(path,'PASS','NULL; no usable value' if value is None else typename(value))


def output_text(body):
    if not isinstance(body,dict): return ''
    output=body.get('output')
    if not isinstance(output,list): return ''
    chunks=[]
    for item in output:
        if not isinstance(item,dict) or item.get('type')!='message': continue
        content=item.get('content')
        if not isinstance(content,list): continue
        for part in content:
            if isinstance(part,dict) and part.get('type')=='output_text' and isinstance(part.get('text'),str): chunks.append(part['text'])
    return ''.join(chunks)


def validate_structured(v):
    return isinstance(v,dict) and set(v)=={'query','posts','summary'} and isinstance(v['query'],str) and isinstance(v['summary'],str) and isinstance(v['posts'],list) and all(isinstance(p,dict) and set(p)=={'url','author','claim'} and all(isinstance(x,str) for x in p.values()) for p in v['posts'])


def repetition(items):
    rows=[]
    for name,o in items:
        if o['metadata']['source']!='xai' or not name.startswith('repeat_'): continue
        t=output_text(o['response']); b=o['response']
        try: obj=json.loads(t); valid=validate_structured(obj)
        except (ValueError,TypeError): obj=None; valid=False
        counts={k:(None if get(b,'usage.server_side_tool_usage_details.'+k) is MISSING else get(b,'usage.server_side_tool_usage_details.'+k)) for k in ('x_search_calls','x_posts_fetched','x_users_fetched')}
        rows.append(dict(fixture=name,http_status=o['metadata']['http_status'],text_sha256=digest(t.encode()) if t else None,canonical_output_sha256=digest(json.dumps(obj,sort_keys=True).encode()) if obj is not None else None,structured_valid=valid,usage=counts,request_sha256=digest(json.dumps(o['metadata']['request_json'],sort_keys=True).encode()),post_urls=sorted({p['url'] for p in obj['posts']}) if valid else []))
    hashes=[r['canonical_output_sha256'] for r in rows if r['canonical_output_sha256']]
    return dict(runs=rows,identical_requests=len(rows)==3 and len({r['request_sha256'] for r in rows})==1,structured_stable=len(rows)==3 and all(r['structured_valid'] for r in rows),variation_observed=len(set(hashes))>1,comparison_complete=len(rows)==3 and len(hashes)==3,note='Missing usage is unknown, never zero. Three runs characterize this query/window only; no accuracy or determinism claim.')


def candidates(value):
    # Observed discovery shape is retained; never invent token addresses.
    if isinstance(value,dict) and isinstance(value.get('items'),list):
        value=value['items']
    if isinstance(value,list):
        for entry in value:
            if isinstance(entry,dict):
                mint=entry.get('mint') or entry.get('tokenAddress')
                if isinstance(mint,str) and re.fullmatch(r'[1-9A-HJ-NP-Za-km-z]{32,44}',mint): yield mint


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--all',action='store_true',help='Default; capture all four providers')
    ap.add_argument('--offline',action='store_true',help='No network; report missing evidence (smoke test only)')
    ap.add_argument('--validate-only',type=Path,help='Revalidate an existing run without requests')
    ap.add_argument('--timeout',type=int,default=45)
    args=ap.parse_args(argv); load_env()
    if args.validate_only:
        root=args.validate_only.resolve(); items=[]
        for p in sorted((root/'tests'/'fixtures').glob('*/*.json')):
            obj=json.loads(p.read_text(encoding='utf-8')); items.append((p.stem,obj))
        summarize(root,items); return 2
    root=ROOT/'results'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:6]); root.mkdir(parents=True)
    cap=Capture(root,args.timeout)
    if args.offline:
        for source in PROVIDERS: cap.skip(source,'offline','OFFLINE_SMOKE_TEST; no live requests made')
    else:
        config=json.loads((ROOT/'probe_config.json').read_text(encoding='utf-8'))
        # Stable normal candidate, then bounded discovery for fresh/risky/rugged.
        reports={}
        def rug(mint,name,labels):
            o=cap.request('rugcheck',name,RUG+'/v1/tokens/'+urllib.parse.quote(mint,safe='')+'/report',labels=labels)
            o['metadata']['requested_mint']=mint; cap.save('rugcheck',name,o); reports[mint]=(name,o); return o
        rug(USDC,'normal_candidate',['normal_candidate'])
        rug('not-a-valid-mint','invalid_mint',['invalid'])
        # Random valid-length public-key bytes, not a wallet/keypair; existence unconfirmed.
        alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
        n=int.from_bytes(hashlib.sha256(uuid.uuid4().bytes).digest(),'big'); mint=''
        while n: n,r=divmod(n,58); mint=alphabet[r]+mint
        rug(mint,'nonexistent_candidate',['nonexistent_candidate_NOT_PROVEN'])
        discovered=[]
        for endpoint,label in (('/v1/stats/rugs/ticker?limit=4','dead_rugged_candidate'),('/v1/stats/new_tokens','fresh_candidate'),('/v1/stats/trending','discovery_candidate')):
            o=cap.request('rugcheck','discover_'+label,RUG+endpoint,role='discovery')
            if good(o): discovered.extend((m,label) for m in list(candidates(o['response']))[:4])
        for category in ('fresh','risky','dead_rugged'):
            for m in config.get('rugcheck_mints',{}).get(category,[]): discovered.insert(0,(m,category+'_candidate'))
        for m,label in discovered:
            if len(reports)>=config['max_rugcheck_reports']: break
            if m not in reports: rug(m,'candidate_'+str(len(reports)),[label])
        # Bounded multi-pool observations; no primary-pool rule selection.
        tokens=[USDC,SOL]+[m for m in reports if m not in (USDC,SOL) and re.fullmatch(r'[1-9A-HJ-NP-Za-km-z]{32,44}',m)]
        dex_records=[]
        for m in tokens[:config['max_dex_tokens']]:
            name='token_'+str(len(dex_records))
            o=cap.request('dexscreener',name,DEX+'/token-pairs/v1/solana/'+m)
            o['metadata']['requested_mint']=m; cap.save('dexscreener',name,o); dex_records.append((m,o))
        # A small-liquidity token is selected only when a returned pool proves the band.
        small=config.get('small_token_mint') or None
        small_evidence=None
        for m,o in dex_records:
            if m in (SOL,USDC) or not good(o) or not isinstance(o['response'],list): continue
            vals=[get(p,'liquidity.usd') for p in o['response'] if get(p,'baseToken.address')==m]
            vals=[v for v in vals if isinstance(v,(int,float)) and v>0]
            if vals and 100<=max(vals)<=100000:
                small=m; small_evidence={'source':'dexscreener','mint':m,'max_returned_pool_liquidity_usd':max(vals)}; break
        dump(root/'small_token_selection.json',{'mint':small,'evidence':small_evidence,'status':'OBSERVED_LIQUIDITY_BAND' if small_evidence else 'USER_CANDIDATE_UNCONFIRMED' if small else 'NOT_AVAILABLE'})
        def quote(m1,m2,amount,name):
            params={'inputMint':m1,'outputMint':m2,'amount':str(amount)}
            o=cap.request('jupiter',name,JUP,params=params)
            o['metadata']['quote_params']=params; cap.save('jupiter',name,o); return o
        for m,label in [(USDC,'liquid')]+([(small,'small')] if small else []):
            forward=quote(SOL,m,10000000,label+'_forward')
            if positive_quote(forward): quote(m,SOL,forward['response']['outAmount'],label+'_reverse')
            else: cap.skip('jupiter',label+'_reverse','Forward outAmount unavailable; no guessed token units')
        if not small: cap.skip('jupiter','small_token','No live-confirmed small-liquidity candidate within bounded discovery')
        quote(SOL,mint,10000000,'no_route_candidate')
        quote(mint,SOL,1,'no_route_reverse_candidate')
        if not os.environ.get('XAI_API_KEY'):
            cap.skip('xai','missing_key','Set XAI_API_KEY in local .env; never paste it into chat')
        else:
            # Fixed dates and identical serialized request for all three independent calls.
            end=dt.datetime.now(dt.timezone.utc).date(); start=end-dt.timedelta(days=7)
            query=f'Search X for posts by @solana from {start} to {end} about Solana network updates. Return at most 3 posts. Use x_search at least once. Report only what the returned posts say; do not assess investment merit.'
            post_schema={'type':'object','properties':{k:{'type':'string'} for k in ('url','author','claim')},'required':['url','author','claim'],'additionalProperties':False}
            schema={'type':'object','properties':{'query':{'type':'string'},'posts':{'type':'array','items':post_schema},'summary':{'type':'string'}},'required':['query','posts','summary'],'additionalProperties':False}
            body={'model':os.environ.get('XAI_MODEL','grok-4.7'),'input':query,'tools':[{'type':'x_search','allowed_x_handles':['solana'],'from_date':str(start),'to_date':str(end)}],'max_turns':2,'max_output_tokens':1800,'store':False,'text':{'format':{'type':'json_schema','name':'phase1_x_search','strict':True,'schema':schema}}}
            for i in range(3): cap.request('xai',f'repeat_{i+1}',XAI,body=body)
    summarize(root,cap.items)
    print('Results:',root)
    print('Return ZIP:',root.with_suffix('.zip'))
    print('Phase 1: LIVE_VALIDATION_PENDING. Phase 2: STOPPED. Exit 2 is intentional.')
    return 2


def summarize(root,items):
    results=[check_fixture(n,o,root) for n,o in items]
    rep=repetition(items)
    coverage={p:{'live_http_responses':sum(o['metadata']['source']==p and o['metadata'].get('provenance')=='live_capture' for _,o in items),'passing_core_fixtures':sum(r['source']==p and r['status']=='PASS' and next(o for n,o in items if n==r['fixture'] and o['metadata']['source']==p)['metadata'].get('role')!='discovery' for r in results)} for p in PROVIDERS}
    category={'normal_candidate':False,'fresh_candidate':False,'risky_observed':False,'rugged_observed':False,'invalid_requested':False,'nonexistent_candidate_requested':False}
    for n,o in items:
        if o['metadata']['source']!='rugcheck': continue
        b=o['response']; labels=o['metadata'].get('labels',[])
        category['invalid_requested'] |= n=='invalid_mint' and o['metadata'].get('provenance')=='live_capture'
        category['nonexistent_candidate_requested'] |= n=='nonexistent_candidate' and o['metadata'].get('provenance')=='live_capture'
        if good(o) and isinstance(b,dict):
            category['normal_candidate'] |= 'normal_candidate' in labels
            # Discovery freshness is only a candidate; pair age is not mint creation age.
            category['fresh_candidate'] |= 'fresh_candidate' in labels
            category['risky_observed'] |= isinstance(b.get('risks'),list) and any(isinstance(r,dict) and r.get('level')=='danger' for r in b['risks'])
            category['rugged_observed'] |= b.get('rugged') is True
    summary={'phase1':'LIVE_VALIDATION_PENDING','phase2':'STOPPED_NOT_AUTHORIZED','generated_at':now(),'existing_contract_tests':'NOT_AVAILABLE_IN_CURRENT_WORKSPACE; new provisional contracts only','original_code_comparison':'UNCONFIRMED; original Phase 1 source ZIP unavailable','phase2_approved_fields':[],'coverage':coverage,'rugcheck_category_coverage':category,'counts':dict(collections.Counter(r['status'] for r in results)),'optional_missing':sum(r.get('optional_missing',0) for r in results),'reproducibility':rep,'completion_blockers':['Original Phase 1 tests/source required for comparison and execution','Manual review of required/optional/unreliable semantics','No automatic Phase 1 COMPLETE or Phase 2 approval'],'contracts':results}
    if not all(coverage[p]['passing_core_fixtures']>0 for p in PROVIDERS): summary['completion_blockers'].append('At least one core API lacks a passing live fixture')
    if not rep['comparison_complete']: summary['completion_blockers'].append('Three xAI structured responses not all available')
    dump(root/'summary.json',summary)
    dump(root/'contract_results.json',results)
    dump(root/'xai_reproducibility.json',rep)
    lines=['# PHASE 1 LIVE VALIDATION — INTERIM REPORT','','Status: **LIVE_VALIDATION_PENDING**. Phase 2: **STOPPED**.','', 'No documentation examples count as live fixtures. HTTP errors are live captures, not successful API validation. Browser observations with unknown status do not count.','', '| Provider | Captured HTTP responses | Passing core fixtures |','|---|---:|---:|']
    for p,c in coverage.items(): lines.append(f'| {p} | {c["live_http_responses"]} | {c["passing_core_fixtures"]} |')
    sections=[('1. Actual endpoints and 2. HTTP results','See request table below.'),('3. Live fixtures','tests/fixtures/{rugcheck,dexscreener,jupiter,xai}/: .body raw bytes + .json metadata/parsed response; SHA256 checks. Redacted raw bytes explicitly flagged.'),('4. Observed schema','contract_results.json observed_schema and exact field paths; observations are sample-specific, not provider guarantees.'),('5. REQUIRED fields','Provisional probe requirements: RugCheck mint/risks/score_normalised/token; DexScreener token/pair identities; Jupiter mint/amount identities and nonempty route; xAI completed output/usage/id and demonstrated x_search.'),('6. OPTIONAL fields','OPTIONAL_MISSING records per fixture. Absence and null remain distinct. All requested Jupiter fields preserved if supplied; never synthesize quoteId/expireAt.'),('7. UNRELIABLE fields','Risk scores and insider/creator data require semantic review. Nullable holders are not zero holders. Missing LP lock data is not unlocked LP. Price impact units are not normalized. Volumes/activity refer to h24 and returned pools only.'),('8. Original-code differences','UNCONFIRMED: original Phase 1 sources and tests unavailable. This tool does not pretend to replace verification of those tests.'),('9. Contract results',json.dumps(summary['counts'])+'; optional missing='+str(summary['optional_missing'])+'. New provisional contracts only.'),('10. API errors','Inspect .body and metadata.http_status. 401/403/429 or transport failure opens a per-host circuit; no automatic retries. NO_ROUTE only when explicitly returned, never inferred from auth/invalid mint.'),('11. Phase 2 approved fields','NONE. User approval required. No field mapping is approved by this tool.'),('12. Remaining risks', '; '.join(summary['completion_blockers']))]
    for title,body in sections: lines+=['','## '+title,'',body]
    lines+=['','## Calls','','| Source / fixture | HTTP | Contract | Endpoint |','|---|---|---|---|']
    for (n,o),r in zip(items,results):
        m=o['metadata']; lines.append(f'| {m["source"]}/{n} | {m.get("http_status")} | {r["status"]} | {m.get("endpoint")} |')
    lines+=['','## Category coverage','', '```json',json.dumps(category,indent=2),'```','','Fresh/normal labels are candidate provenance, not verified ground truth. Risky means provider returned a danger-level risk; rugged means provider rugged=true. Missing categories remain unconfirmed.','','## xAI reproducibility','', '```json',json.dumps(rep,indent=2),'```','','STOP. Do not begin Phase 2. PHASE1_FINAL_REPORT.md is intentionally not generated before full live review.']
    (root/'PHASE1_INTERIM_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    # Explicit allowlist. Never include .env, user home, source tree or unrelated files.
    files=[p for p in root.rglob('*') if p.is_file() and (p.suffix in ('.json','.body') or p.name=='PHASE1_INTERIM_REPORT.md')]
    for p in files:
        safe,changed=scrub(p.read_bytes())
        if changed: raise RuntimeError('Secret scan blocked ZIP; inspect local result without sharing')
    manifest={str(p.relative_to(root)):digest(p.read_bytes()) for p in files}
    dump(root/'MANIFEST.sha256.json',manifest); files.append(root/'MANIFEST.sha256.json')
    with zipfile.ZipFile(root.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
        for p in files: z.write(p,p.relative_to(root))


if __name__=='__main__':
    try: sys.exit(main())
    except KeyboardInterrupt:
        print('Interrupted. No automatic retry. Partial files remain local.'); sys.exit(130)
