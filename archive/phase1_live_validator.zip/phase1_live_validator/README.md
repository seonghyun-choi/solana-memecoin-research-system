# Phase 1 live validator — Phase 2 STOPPED

현재 상태: **LIVE_VALIDATION_PENDING / PARTIALLY EXECUTED**.
기존 Phase 1 ZIP/원문 코드/contract tests는 이번 작업 공간과 파일 검색에서 확보되지 않았습니다.
이 패키지는 독립적인 수집기와 신규 잠정 contract validator입니다. 기존 테스트를 실행했다고 주장하지 않습니다.

## 한 번 실행하기

1. Python 3.10 이상이 설치된 인터넷 사용 가능한 PC에서 ZIP을 풉니다.
2. `.env.example`을 `.env`로 복사하고 `XAI_API_KEY=` 뒤에 본인의 키를 입력합니다.
3. 이 폴더에서 실행합니다.

```bash
python live_probe.py
```

`python live_probe.py --all`도 동일합니다. Windows에서는 `run_windows.bat`을 더블클릭해도 됩니다.
외부 Python dependency가 없어 `pip install`은 필요하지 않습니다.
xAI는 동일 요청을 3회 보내므로 계정의 API 요금이 발생합니다. 각 요청은 max_turns=2,
max_output_tokens=1800으로 제한하지만 이것이 달러 단위 비용 상한은 아닙니다.

실행 후 표시되는 `results/<UTC timestamp>_<run id>.zip`만 반환하세요.
`.env`, API 키, 개인키는 보내지 마세요. ZIP은 결과 파일 allowlist로만 생성됩니다.
Jupiter keyless 접근이 401/403을 반환하는 경우에만 `.env`의 `JUPITER_API_KEY`를
로컬에서 설정한 뒤 새로 실행합니다. HTTP 오류를 NO_ROUTE로 바꾸지 않습니다.

## 자동 생성

각 실행은 별도 폴더로 보존되며 이전 실행을 덮어쓰지 않습니다.

- `tests/fixtures/rugcheck/`
- `tests/fixtures/dexscreener/`
- `tests/fixtures/jupiter/`
- `tests/fixtures/xai/`
- `contract_results.json`: PASS / FAIL / OPTIONAL_MISSING / SCHEMA_CHANGED / NOT_RUN
- `summary.json`, `xai_reproducibility.json`, `small_token_selection.json`
- `PHASE1_INTERIM_REPORT.md`: 요청한 12개 보고 항목의 현재 상태
- `MANIFEST.sha256.json`: 결과 파일 해시

HTTP 응답을 받으면 `.body`에 원문 bytes, `.json`에 파싱된 응답과 metadata를 저장합니다.
metadata: source, endpoint, captured_at(UTC), http_status, provenance=live_capture,
api_version, fixture_format_version, 서버 schemaVersion/version(존재 시), SHA256,
허용된 응답 헤더, latency, request body/parameters. 요청 인증 헤더는 저장하지 않습니다.
비밀값이 응답에 반사되면 해당 값만 제거하고 `raw_body_redacted=true`를 기록합니다.
이 경우 보존된 원문은 redacted 원문이며 원래 bytes와 같다고 주장하지 않습니다.
네트워크 실패/키 누락/회로 차단은 provenance=not_captured이고 성공 fixture가 아닙니다.

## 수집 범위와 한계

- RugCheck: USDC normal 후보, malformed mint, 무작위 32-byte public-address 후보,
  recent-rugs ticker / new_tokens / trending에서 최대 12개 후보를 발견합니다.
  총 report 최대 15개. 주소를 만들어 fresh/risky/rugged로 꾸미지 않습니다.
  `rugged=true`는 provider의 판단, danger risk는 provider risk 관찰입니다.
  fresh 목록은 최근 **감지**이지 mint 생성 시간 증명이 아닙니다.
  후보를 못 찾거나 endpoint가 실패하면 해당 유형은 미확인으로 남습니다.
  `probe_config.json`에서 검증할 실제 mint를 추가할 수 있습니다.
- DexScreener: 최대 10 token 요청. h24 거래량, h24 buys+sells, USD liquidity의
  최댓값을 각각 비교하며 동률과 누락을 보존합니다. 조회된 pool 범위만의 관찰이며
  전체 시장을 대표하거나 primary-pool 선택 규칙을 정하지 않습니다.
  baseToken이 대상 mint인 pool만 가격/순위 관찰에 사용합니다.
- Jupiter: `/swap/v2/order`만 GET, taker/wallet/payer 미전달. SOL→USDC 후 실제
  outAmount를 사용해 USDC→SOL을 요청합니다. 발견된 후보의 반환 pool 최대 liquidity가
  $100~$100,000이면 small 후보로 추가합니다. 이는 수집 표본 내 유동성 기준입니다.
  small 미발견은 skip. 무작위 주소 후보 양방향도 요청하지만 NO_ROUTE가 반드시 나오지는 않습니다.
  `transaction`이 null/빈 문자열 외 값이면 FAIL. build/execute/sign/submit 기능은 없습니다.
- xAI: `/v1/responses`, x_search, JSON Schema 출력. 동일 모델/날짜 범위/입력/스키마를
  세 번 요청하고 raw output, canonical JSON 해시, post URL 목록, 사용량을 비교합니다.
  `usage.server_side_tool_usage_details`에서 x_search_calls/x_posts_fetched/x_users_fetched를
  읽습니다. 누락은 null/OPTIONAL_MISSING이며 0으로 보정하지 않습니다.
  응답이 completed이고 실제 x_search_calls>0이어야 통과합니다.
  이 실험은 정확도 평가나 장기 재현성 보장이 아닙니다.

기본적으로 호스트별 2.1초 간격, 재시도 없음. 401/403/429 또는 transport failure이면
해당 호스트의 나머지 호출을 skip합니다. 오류 body/status는 보존합니다.
일반 GET timeout 45초, xAI 최대 180초(각 socket timeout)입니다.

## 검증과 완료 기준

```bash
python -m unittest discover -s tests -v
python live_probe.py --validate-only results/<run-folder>
```

첫 명령은 **합성 unit tests**이며 live 검증과 별개입니다. 두 번째는 추가 API 호출 없이
기존 원문 해시, 파싱 일치, 잠정 필드 계약, 의미상 최소 조건을 검사하고 summary/ZIP을 갱신합니다.
`python live_probe.py --offline`은 연결 없이 결과 생성 경로만 확인하는 smoke test입니다.
문서 예제나 합성 응답은 live fixture 디렉터리에 넣지 마세요.

종료 코드 2는 **검토 대기**를 뜻하며 보고서/ZIP은 정상 생성될 수 있습니다.
현재 코드에는 자동 COMPLETE 경로가 없습니다. 기존 원문 코드/테스트와의 비교 및
실제 응답 검토가 필요합니다. 결과 ZIP과 기존 Phase 1 소스 ZIP이 확보되면 기존 tests를
연결해 실행하고 최종 보고서를 작성할 수 있습니다.

**PHASE1_FINAL_REPORT.md는 아직 만들지 않습니다. Phase 2 승인 field 목록은 비어 있습니다.**

## 이 환경에서 확인한 내용

`evidence/BROWSER_OBSERVATIONS.md`를 보세요. Browser에서 일부 실제 응답 본문을 확인했지만
HTTP status를 검증할 수 없어 완료 증거로 세지 않습니다. 원문/화면 관찰은 local live capture와
분리했습니다. 일반 runtime 한 번의 요청은 403이었고 추가 runtime 요청은 하지 않았습니다.

## 공식 문서 (fixture가 아님)

- https://api.rugcheck.xyz/swagger/doc.json
- https://docs.dexscreener.com/api/reference
- https://developers.jup.ag/docs/swap/order-and-execute
- https://github.com/jup-ag/docs/blob/main/llms.txt
- https://docs.x.ai/developers/tools/x-search
- https://docs.x.ai/developers/model-capabilities/text/structured-outputs
- https://docs.x.ai/developers/rest-api-reference/inference/responses

문서 확인일: 2026-10-28. 문서 규격과 live observation을 혼동하지 않습니다.
