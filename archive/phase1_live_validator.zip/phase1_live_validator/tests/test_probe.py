"""Synthetic unit/transport tests, never live validation evidence."""
import io, json, os, tempfile, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
import live_probe as p
class Response(io.BytesIO):
    def __init__(self,raw,code=200):
        super().__init__(raw); self.code=code; self.headers={'Content-Type':'application/json'}
class Opener:
    def __init__(self,raw,code=200): self.raw,self.code,self.requests=raw,code,[]
    def open(self,request,**kwargs): self.requests.append(request); return Response(self.raw,self.code)
class Tests(unittest.TestCase):
    def setUp(self): self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()
    def test_raw_bytes_status_hash_redaction_and_circuit(self):
        op=Opener(b'{"message":"secret-value-123"}',401)
        with patch.dict(os.environ,{'XAI_API_KEY':'secret-value-123'}):
            c=p.Capture(self.root,opener=op); o=c.request('xai','one',p.XAI,body={'input':'hello'})
            self.assertEqual(o['metadata']['http_status'],401)
            self.assertTrue(o['metadata']['raw_body_redacted'])
            self.assertNotIn(b'secret-value-123',(self.root/'tests/fixtures/xai/one.body').read_bytes())
            c.request('xai','two',p.XAI,body={'input':'hello'}); self.assertEqual(len(op.requests),1)
    def test_jupiter_rejects_wallet_and_build(self):
        c=p.Capture(self.root)
        with self.assertRaises(ValueError): c.request('jupiter','bad',p.JUP,params={'taker':'address'})
        with self.assertRaises(ValueError): c.request('jupiter','bad',p.JUP.replace('order','build'))
    def test_quote_only_request(self):
        op=Opener(b'{}'); c=p.Capture(self.root,opener=op)
        c.request('jupiter','safe',p.JUP,params={'inputMint':p.SOL,'outputMint':p.USDC,'amount':'10'})
        self.assertEqual(op.requests[0].get_method(),'GET'); self.assertNotIn('taker',op.requests[0].full_url)
    def test_missing_null_type(self):
        rows=[]; rec=lambda f,s,n:rows.append(s)
        p.field_check({},'risks',('array',),True,rec)
        p.field_check({},'topHolders',('array','null'),False,rec)
        p.field_check({'topHolders':None},'topHolders',('array','null'),False,rec)
        p.field_check({'risks':'none'},'risks',('array',),True,rec)
        self.assertEqual(rows,['SCHEMA_CHANGED','OPTIONAL_MISSING','PASS','SCHEMA_CHANGED'])
    def test_pool_rankings_ties_and_orientation(self):
        def pool(id,liq,vol,buys,mint='M'):
            return dict(pairAddress=id,chainId='solana',baseToken={'address':mint},liquidity={'usd':liq},volume={'h24':vol},txns={'h24':{'buys':buys,'sells':0}})
        rows=[pool('a',100,2,3),pool('b',20,200,4),pool('c',30,3,300),pool('ignore',999,999,999,'OTHER')]
        o=p.pool_observation(rows,'M'); self.assertTrue(o['all_three_distinct_observed'])
        self.assertEqual(o['winners']['deepest_pool'][0]['pairAddress'],'a')
        rows.append(pool('tie',100,1,1)); self.assertEqual(len(p.pool_observation(rows,'M')['winners']['deepest_pool']),2)
    def test_nonlive_never_passes(self):
        r=p.check_fixture('fake',{'metadata':{'source':'rugcheck','provenance':'documentation_example'},'response':{'risks':[]}},self.root)
        self.assertEqual(r['status'],'NOT_RUN')
    def test_raw_tampering(self):
        c=p.Capture(self.root,opener=Opener(b'{"mint":"m","risks":[],"score_normalised":1,"token":{}}'))
        o=c.request('rugcheck','normal',p.RUG+'/v1/tokens/m/report')
        (self.root/'tests/fixtures/rugcheck/normal.body').write_bytes(b'{}')
        self.assertEqual(p.check_fixture('normal',o,self.root)['status'],'FAIL')
    def test_xai_tool_use_and_output_schema(self):
        b={'id':'r','status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':json.dumps({'query':'q','summary':'s','posts':[]})}]}],'usage':{'server_side_tool_usage_details':{'x_search_calls':0}}}
        c=p.Capture(self.root,opener=Opener(json.dumps(b).encode())); o=c.request('xai','repeat_1',p.XAI,body={'input':'q'})
        self.assertEqual(p.check_fixture('repeat_1',o,self.root)['status'],'FAIL')
        self.assertFalse(p.validate_structured({'query':'q','summary':'s','posts':[{'url':5,'author':'a','claim':'c'}]}))
    def test_error_not_quote(self):
        o={'metadata':{'provenance':'live_capture','http_status':401},'response':{'error':'Unauthorized'}}
        self.assertFalse(p.positive_quote(o))
    def test_exact_nested_paths(self):
        v={'token':{'mintAuthority':None},'mintAuthority':{'owner':'x'},'markets':[{'lp':{'lpLockedPct':88}}]}
        self.assertEqual(p.find_keys(v,'lpLockedPct')[0]['path'],'$.markets[0].lp.lpLockedPct')
        self.assertEqual(len(p.find_keys(v,'mintAuthority')),2)
    def test_zip_allowlist_and_pending(self):
        c=p.Capture(self.root)
        for source in p.PROVIDERS: c.skip(source,'offline','No network')
        (self.root/'.env').write_text('XAI_API_KEY=do-not-include')
        p.summarize(self.root,c.items)
        self.assertEqual(json.loads((self.root/'summary.json').read_text())['phase1'],'LIVE_VALIDATION_PENDING')
        with zipfile.ZipFile(self.root.with_suffix('.zip')) as z:self.assertNotIn('.env',z.namelist())
        self.root.with_suffix('.zip').unlink()
if __name__=='__main__':unittest.main()

class EndToEnd(unittest.TestCase):
    def test_all_providers_mocked_never_complete(self):
        class MockNetwork:
            def open(self, req, **kwargs):
                from urllib.parse import urlsplit, parse_qs
                u=urlsplit(req.full_url); q=parse_qs(u.query); status=200
                if '/stats/' in u.path:
                    b={'items':[{'mint':'A'*32}]} if 'rugs' in u.path else [{'mint':'B'*32}]
                elif 'rugcheck' in u.netloc:
                    mint=u.path.split('/')[-2]
                    if mint=='not-a-valid-mint': b={'error':'invalid mint'}; status=400
                    else: b={'mint':mint,'token':{'mintAuthority':None,'freezeAuthority':None},'risks':[{'level':'danger'}] if mint=='A'*32 else [],'score_normalised':1,'rugged':mint=='A'*32}
                elif 'dexscreener' in u.netloc:
                    mint=u.path.split('/')[-1]
                    b=[{'baseToken':{'address':mint},'quoteToken':{'address':p.SOL},'chainId':'solana','pairAddress':'pool','dexId':'test','liquidity':{'usd':1000},'volume':{'h24':25},'txns':{'h24':{'buys':1,'sells':2}}}]
                elif 'jup.ag' in u.netloc:
                    b={'inputMint':q['inputMint'][0],'outputMint':q['outputMint'][0],'inAmount':q['amount'][0],'outAmount':'100','routePlan':[{}],'transaction':None}
                else:
                    b={'id':'response','status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':json.dumps({'query':'q','posts':[],'summary':'s'})}]}],'usage':{'server_side_tool_usage_details':{'x_search_calls':1,'x_posts_fetched':2,'x_users_fetched':0}}}
                return Response(json.dumps(b).encode(),status)
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            p.dump(root/'probe_config.json',{'max_rugcheck_reports':15,'max_dex_tokens':10,'rugcheck_mints':{},'small_token_mint':''})
            with patch.object(p,'ROOT',root),patch('urllib.request.build_opener',return_value=MockNetwork()),patch('time.sleep'),patch.dict(os.environ,{'XAI_API_KEY':'unit-test-secret'}):
                self.assertEqual(p.main(['--all']),2)
            s=json.loads(next((root/'results').glob('*/summary.json')).read_text())
            self.assertTrue(all(v['passing_core_fixtures']>0 for v in s['coverage'].values()))
            self.assertTrue(s['reproducibility']['comparison_complete'])
            self.assertTrue(s['rugcheck_category_coverage']['rugged_observed'])
            self.assertEqual(s['phase1'],'LIVE_VALIDATION_PENDING')
            self.assertEqual(s['phase2_approved_fields'],[])
