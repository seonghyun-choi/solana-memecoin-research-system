@echo off
cd /d "%~dp0"
python live_probe.py --all
pause
