# Browser observations — 2026-10-28

Status: partial live body observation only. **Not qualified live fixtures.**
Transport: Cloud Browser direct navigation to official endpoints.
The exposed DOM supplies response text but not verified HTTP status/headers.
HTTP status: UNCONFIRMED. Exact server capture time: UNCONFIRMED.
These observations never count toward the contract success/Phase 1 completion gate.
Documentation examples were not used as live data.

## Runtime path

One urllib request to the DexScreener SOL token-pairs endpoint returned HTTPError 403.
This is an observed access failure, not proof of a DNS error and not proof of a provider 403.
No repeated runtime network probe was made. No API key was requested or used.

## RugCheck

GET https://api.rugcheck.xyz/v1/tokens/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/report

Actual displayed report observations:

| Requested field | Exact observed path | Value/type | Scope |
|---|---|---|---|
| score_normalised | $.score_normalised | 1 / number | This response only |
| risks | $.risks | [] / array | No inferred safety guarantee |
| mintAuthority | $.token.mintAuthority | address string | Token authority address |
| mintAuthority | $.mintAuthority | object | Account details, not an address |
| freezeAuthority | $.token.freezeAuthority | address string | Token authority address |
| freezeAuthority | $.freezeAuthority | object | Account details, not an address |
| lpLockedPct | No exact key found | NOT_AVAILABLE | markets=null, do not map total liquidity to lock % |
| topHolders | $.topHolders | null | Not an empty holder set |
| creator | $.creator | address string | Provider-reported creator |
| creatorBalance | $.creatorBalance | 0 / number | Units/semantics not confirmed |
| creatorTokens | $.creatorTokens | null | Not available |
| insider information | $.graphInsidersDetected | 0 / number | Does not establish absence of insiders |
| insider information | $.insiderNetworks | null | Not available |

Other relevant observations: totalMarketLiquidity=0, totalHolders=0, price=0,
markets=null even for USDC; these are not usable proof of actual USDC market liquidity/holders/price.
rugged=false. detectedAt=2026-04-15T13:21:48.040036252Z is a report field, not this capture time.

GET https://api.rugcheck.xyz/v1/tokens/not-a-valid-mint/report

Displayed raw response:
```json
{"error":"invalid encoded length, expected 32 to 44, got 16"}
```
HTTP status is unknown; no guessed 400/404 classification.

GET https://api.rugcheck.xyz/v1/stats/rugs/ticker?limit=3

Displayed items contained actual mint candidates:
BVd95uVAr6W2pWaNCBkntgKa9gGAsMaPV83TzbcDuB5w,
27GdtqwMkUXR3avS9VVyE2CU5joxqE4WWxgSJTJ6pump,
Hxt9QAaTcmC2d4kDKndpNo2TALq8PWF3vFACzYgvpump.
These are discovery candidates, not independently verified rugged report fixtures.
The local tool discovers current candidates rather than freezing this transient list.

## DexScreener

GET https://api.dexscreener.com/token-pairs/v1/solana/So11111111111111111111111111111111111111112

Displayed a 30-pool JSON array for SOL, including Orca, Raydium, Meteora and PumpSwap.
Observed priceUsd string, liquidity.usd number, pairCreatedAt millisecond number,
txns/volume objects, baseToken/quoteToken objects, dexId string.
fdv/marketCap were absent from multiple pools and present in some Meteora pools.
No assumption that those fields are universally required.

For the displayed snapshot, Orca pool Czfq3xZZDmsdGdUyrNLtRhGc47cXcZtLG4crryfu44zE
had liquidity.usd=29,158,576.25, volume.h24=64,666,034.81,
txns.h24 buys=30,974 and sells=33,427 (sum=64,401).
These were the largest displayed values in all three categories.
**Different winners were not observed in this one response.** This does not prove
that different winners never exist. No selection-rule optimization performed.
Full byte-exact HTTP response/status not exported through Browser; local tool recaptures it.

## Jupiter Swap V2

GET https://api.jup.ag/swap/v2/order?inputMint=So11111111111111111111111111111111111111112&outputMint=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v&amount=10000000

Forward: inAmount=10000000, outAmount=1019130, router=metis,
transaction=null, taker=null, feeBps=2, slippageBps=0,
priceImpactPct="0.0004286454875965248", priceImpact=0.04286454875965248,
inUsdValue=1.018063113811908, outUsdValue=1.018499501971732, totalTime=139,
requestId=01a180fd-0b46-7369-9b4f-f2605e402e0f. routePlan present.
quoteId and expireAt absent; not synthesized.

GET https://api.jup.ag/swap/v2/order?inputMint=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v&outputMint=So11111111111111111111111111111111111111112&amount=1019130

Reverse: inAmount=1019130, outAmount=9998104, router=metis,
transaction=null, taker=null, feeBps=2, slippageBps=0,
priceImpactPct="0.000798234862167005", priceImpact=0.0798234862167005,
inUsdValue=1.0184918778259693, outUsdValue=1.019304873549684, totalTime=150,
requestId=01a180fd-bf67-76fb-ab34-9d362912b80b. routePlan present (three legs).
quoteId and expireAt absent. Reverse route observed for this mint/amount/time only.

The two priceImpact fields differ numerically by a factor of 100 in these observations.
Do not equate or silently normalize them; preserve both until semantic review.
No transaction was created by the requests: taker omitted, returned transaction=null.
No wallet, private key, signing, /build, /execute or transaction submission used.

## xAI

Not called. No XAI_API_KEY available through an authorized local .env in this environment.
Responses API + x_search and 3 repetitions remain pending local execution.
Model defaults and usage paths were checked against official documentation, not a live response.

## Completion

Phase 1 remains PARTIALLY EXECUTED / LIVE_VALIDATION_PENDING.
Existing Phase 1 code/tests could not be retrieved. New validator tests are separately labeled synthetic.
No Phase 2 approval fields. No final report or COMPLETE claim.
